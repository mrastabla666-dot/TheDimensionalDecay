package com.drdecay.decay;

import net.minecraft.block.*;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.fluid.FluidState;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

public class DecayUtil {
    public static final int ANCHOR_RADIUS = 32;

    public static boolean corruptible(BlockState s) {
        return s.isOf(Blocks.BEDROCK) || s.isOf(Blocks.COBBLED_DEEPSLATE)
                || s.isIn(BlockTags.DEEPSLATE_ORE_REPLACEABLES) || s.isIn(BlockTags.STONE_ORE_REPLACEABLES)
                || s.isIn(BlockTags.DIRT);
    }

    public static boolean isProtected(ServerWorld world, BlockPos pos) {
        DecayState ds = DecayState.get(world);
        double r2 = ANCHOR_RADIUS * ANCHOR_RADIUS;
        for (long l : ds.anchors) {
            if (BlockPos.fromLong(l).getSquaredDistance(pos) <= r2) return true;
        }
        return false;
    }

    public static boolean wearsFullNullArmor(LivingEntity e) {
        for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            if (!(e.getEquippedStack(s).getItem() instanceof NullArmorItem)) return false;
        }
        return true;
    }

    /** Water/lava touching corrupted terrain or Null Fluid becomes Null Fluid. */
    public static void convertLiquids(World w, BlockPos pos) {
        for (Direction d : Direction.values()) {
            BlockPos np = pos.offset(d);
            BlockState bs = w.getBlockState(np);
            if (!(bs.getBlock() instanceof FluidBlock)) continue;
            FluidState fs = bs.getFluidState();
            if (fs.isIn(FluidTags.WATER) || fs.isIn(FluidTags.LAVA)) {
                if (w instanceof ServerWorld sw && isProtected(sw, np)) continue;
                w.setBlockState(np, DecayBlocks.NULL_FLUID.getDefaultState());
            }
        }
    }

    public static boolean isRedstoneish(BlockState s) {
        Block b = s.getBlock();
        return b instanceof RedstoneWireBlock || b instanceof AbstractRedstoneGateBlock
                || b instanceof RedstoneTorchBlock || b instanceof LeverBlock || b instanceof ObserverBlock
                || s.isOf(Blocks.REDSTONE_BLOCK) || s.isOf(Blocks.REDSTONE_LAMP);
    }

    public static void breakRedstone(World w, BlockPos pos) {
        for (Direction d : Direction.values()) {
            BlockPos np = pos.offset(d);
            if (isRedstoneish(w.getBlockState(np))) w.breakBlock(np, false);
        }
    }

    /** Carves the void rift and places the Rift Core at the bottom of the world. */
    public static void buildRift(ServerWorld world, DecayState st) {
        BlockPos c = new BlockPos(st.riftX, -58, st.riftZ);
        for (int dx = -5; dx <= 5; dx++)
            for (int dy = -5; dy <= 5; dy++)
                for (int dz = -5; dz <= 5; dz++) {
                    int d2 = dx * dx + dy * dy + dz * dz;
                    BlockPos p = c.add(dx, dy, dz);
                    if (p.getY() < world.getBottomY()) continue;
                    if (d2 <= 16) world.setBlockState(p, Blocks.AIR.getDefaultState(), 2);
                    else if (d2 <= 30 && !world.getBlockState(p).isAir()) world.setBlockState(p, DecayBlocks.CORRUPTED_VOID.getDefaultState(), 2);
                }
        world.setBlockState(new BlockPos(st.riftX, -62, st.riftZ), DecayBlocks.RIFT_CORE.getDefaultState(), 2);
        st.riftPlaced = true;
        st.markDirty();
    }
}
