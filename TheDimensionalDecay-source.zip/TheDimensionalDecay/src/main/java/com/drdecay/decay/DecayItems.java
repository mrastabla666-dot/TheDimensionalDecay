package com.drdecay.decay;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.*;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.util.EnumMap;
import java.util.List;

import static com.drdecay.decay.DimensionalDecay.id;

public class DecayItems {
    public static final Item VOID_SHARD = Registry.register(Registries.ITEM, id("void_shard"), new Item(new Item.Settings()));

    public static final RegistryEntry<ArmorMaterial> NULL_MATERIAL = Registry.registerReference(Registries.ARMOR_MATERIAL, id("null"),
            new ArmorMaterial(
                    Util.make(new EnumMap<ArmorItem.Type, Integer>(ArmorItem.Type.class), m -> {
                        m.put(ArmorItem.Type.BOOTS, 3);
                        m.put(ArmorItem.Type.LEGGINGS, 6);
                        m.put(ArmorItem.Type.CHESTPLATE, 8);
                        m.put(ArmorItem.Type.HELMET, 3);
                        m.put(ArmorItem.Type.BODY, 11);
                    }),
                    18, SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE, () -> Ingredient.ofItems(VOID_SHARD),
                    List.of(new ArmorMaterial.Layer(id("null"))), 3.0f, 0.1f));

    public static final Item NULL_HELMET = armor("null_helmet", ArmorItem.Type.HELMET);
    public static final Item NULL_CHESTPLATE = armor("null_chestplate", ArmorItem.Type.CHESTPLATE);
    public static final Item NULL_LEGGINGS = armor("null_leggings", ArmorItem.Type.LEGGINGS);
    public static final Item NULL_BOOTS = armor("null_boots", ArmorItem.Type.BOOTS);

    public static final Item CRAWLER_EGG = Registry.register(Registries.ITEM, id("bedrock_crawler_spawn_egg"),
            new SpawnEggItem(DecayEntities.BEDROCK_CRAWLER, 0x1A1A1A, 0x8A2BE2, new Item.Settings()));
    public static final Item SPLICER_EGG = Registry.register(Registries.ITEM, id("echo_splicer_spawn_egg"),
            new SpawnEggItem(DecayEntities.ECHO_SPLICER, 0x1E2A44, 0x66CCFF, new Item.Settings()));

    private static Item armor(String name, ArmorItem.Type type) {
        return Registry.register(Registries.ITEM, id(name),
                new NullArmorItem(NULL_MATERIAL, type, new Item.Settings().maxDamage(type.getMaxDamage(40)).fireproof()));
    }

    public static void init() {
        Registry.register(Registries.ITEM_GROUP, id("main"), FabricItemGroup.builder()
                .icon(() -> new ItemStack(DecayBlocks.CORRUPTED_VOID))
                .displayName(Text.translatable("itemGroup.dimensional_decay"))
                .entries((ctx, e) -> {
                    e.add(DecayBlocks.CORRUPTED_VOID);
                    e.add(DecayBlocks.ANCHOR_OF_LIGHT);
                    e.add(DecayBlocks.SEALED_CORE);
                    e.add(VOID_SHARD);
                    e.add(NULL_HELMET); e.add(NULL_CHESTPLATE); e.add(NULL_LEGGINGS); e.add(NULL_BOOTS);
                    e.add(CRAWLER_EGG); e.add(SPLICER_EGG);
                }).build());
    }
}
