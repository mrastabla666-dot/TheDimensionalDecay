package com.drdecay.decay.client;

import com.drdecay.decay.DecayBlocks;
import com.drdecay.decay.DecayEntities;
import com.drdecay.decay.DimensionalDecay;
import com.drdecay.decay.entity.BedrockCrawlerEntity;
import com.drdecay.decay.entity.EchoSplicerEntity;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.SpiderEntityRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.util.Identifier;

public class DimensionalDecayClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.INSTANCE.putBlock(DecayBlocks.NULL_FLUID, RenderLayer.getTranslucent());
        EntityRendererRegistry.register(DecayEntities.BEDROCK_CRAWLER, CrawlerRenderer::new);
        EntityRendererRegistry.register(DecayEntities.ECHO_SPLICER, SplicerRenderer::new);
    }

    static class CrawlerRenderer extends SpiderEntityRenderer<BedrockCrawlerEntity> {
        CrawlerRenderer(EntityRendererFactory.Context ctx) { super(ctx); }
        @Override public Identifier getTexture(BedrockCrawlerEntity e) { return DimensionalDecay.id("textures/entity/bedrock_crawler.png"); }
    }

    static class SplicerRenderer extends BipedEntityRenderer<EchoSplicerEntity, BipedEntityModel<EchoSplicerEntity>> {
        SplicerRenderer(EntityRendererFactory.Context ctx) {
            super(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE)), 0.5f);
        }
        @Override public Identifier getTexture(EchoSplicerEntity e) { return DimensionalDecay.id("textures/entity/echo_splicer.png"); }
    }
}
