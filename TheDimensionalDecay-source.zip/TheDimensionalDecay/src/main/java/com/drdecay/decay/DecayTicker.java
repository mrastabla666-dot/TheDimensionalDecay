package com.drdecay.decay;

import com.drdecay.decay.entity.BedrockCrawlerEntity;
import com.drdecay.decay.entity.EchoSplicerEntity;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class DecayTicker {
    private static final Map<UUID, Float> lastHealth = new HashMap<>();
    private static final Set<UUID> nearCorruption = new HashSet<>();

    public static void init() { ServerTickEvents.END_WORLD_TICK.register(DecayTicker::tick); }

    private static void tick(ServerWorld world) {
        if (world.getRegistryKey() != World.OVERWORLD) return;
        DecayState st = DecayState.get(world);
        long t = world.getTime();

        if (!st.riftSet) {
            BlockPos sp = world.getSpawnPos();
            java.util.Random r = new java.util.Random(world.getSeed() ^ 0xDECA1L);
            double a = r.nextDouble() * Math.PI * 2;
            int d = 300 + r.nextInt(300);
            st.riftX = sp.getX() + (int) (Math.cos(a) * d);
            st.riftZ = sp.getZ() + (int) (Math.sin(a) * d);
            st.riftSet = true;
            st.markDirty();
        }

        // Corrupted ground suppresses natural regeneration
        for (ServerPlayerEntity p : world.getPlayers()) {
            UUID id = p.getUuid();
            if (t % 10 == 0) {
                if (!st.sealed && nearCorrupted(world, p.getBlockPos(), 2)) nearCorruption.add(id);
                else nearCorruption.remove(id);
            }
            float h = p.getHealth();
            Float last = lastHealth.get(id);
            if (last != null && nearCorruption.contains(id) && h > last && !p.isDead()
                    && !p.hasStatusEffect(StatusEffects.REGENERATION)) {
                p.setHealth(last);
                h = last;
            }
            lastHealth.put(id, h);
        }

        if (t % 20 != 0) return;

        for (ServerPlayerEntity p : world.getPlayers()) {
            if (p.isSpectator()) continue;
            BlockPos below = p.getBlockPos().down();

            // Gravity Fracture
            if (!st.sealed && world.getBlockState(below).isOf(DecayBlocks.CORRUPTED_VOID)
                    && !DecayUtil.isProtected(world, below) && !DecayUtil.wearsFullNullArmor(p)) {
                p.addStatusEffect(new StatusEffectInstance(DecayEffects.GRAVITY_FRACTURE, 60, 0, false, true, true));
            }

            // The void creeps up from y=-64; thickness grows with world age
            if (!st.sealed) {
                long day = world.getTimeOfDay() / 24000L;
                int maxY = -64 + (int) Math.min(48, day / 2);
                for (int i = 0; i < 8; i++) {
                    int x = p.getBlockX() + world.random.nextInt(49) - 24;
                    int z = p.getBlockZ() + world.random.nextInt(49) - 24;
                    int y = -64 + world.random.nextInt(maxY + 65);
                    if (!world.getChunkManager().isChunkLoaded(x >> 4, z >> 4)) continue;
                    BlockPos bp = new BlockPos(x, y, z);
                    BlockState s = world.getBlockState(bp);
                    boolean bedrock = s.isOf(Blocks.BEDROCK);
                    if ((bedrock || s.isOf(Blocks.DEEPSLATE)) && (bedrock || exposed(world, bp))
                            && world.random.nextFloat() < 0.4f && !DecayUtil.isProtected(world, bp)) {
                        world.setBlockState(bp, DecayBlocks.CORRUPTED_VOID.getDefaultState());
                    }
                }
            }
        }

        // Rift generation when a player gets close
        if (t % 40 == 0 && !st.riftPlaced && !st.sealed && world.getChunkManager().isChunkLoaded(st.riftX >> 4, st.riftZ >> 4)) {
            for (ServerPlayerEntity p : world.getPlayers()) {
                if (Math.hypot(p.getX() - st.riftX, p.getZ() - st.riftZ) < 96) { DecayUtil.buildRift(world, st); break; }
            }
        }

        // Void mobs near corruption
        if (t % 100 == 0 && !st.sealed) {
            for (ServerPlayerEntity p : world.getPlayers()) {
                if (p.isSpectator()) continue;
                BlockPos c = findCorrupted(world, p.getBlockPos());
                if (c == null) continue;
                Box box = new Box(p.getBlockPos()).expand(48);
                if (world.getEntitiesByClass(BedrockCrawlerEntity.class, box, e -> true).size() < 3 && world.random.nextFloat() < 0.5f) {
                    DecayEntities.BEDROCK_CRAWLER.spawn(world, c.up(), SpawnReason.EVENT);
                }
                boolean onCorrupt = world.getBlockState(p.getBlockPos().down()).isOf(DecayBlocks.CORRUPTED_VOID);
                if (onCorrupt && c.getSquaredDistance(p.getBlockPos()) > 64
                        && world.getEntitiesByClass(EchoSplicerEntity.class, box, e -> true).isEmpty()
                        && world.random.nextFloat() < 0.3f) {
                    DecayEntities.ECHO_SPLICER.spawn(world, c.up(), SpawnReason.EVENT);
                }
            }
        }
    }

    private static boolean exposed(ServerWorld w, BlockPos p) {
        for (net.minecraft.util.math.Direction d : net.minecraft.util.math.Direction.values())
            if (w.getBlockState(p.offset(d)).isAir()) return true;
        return false;
    }

    private static boolean nearCorrupted(ServerWorld w, BlockPos c, int r) {
        for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++)
            if (w.getBlockState(c.add(x, y, z)).isOf(DecayBlocks.CORRUPTED_VOID)) return true;
        return false;
    }

    private static BlockPos findCorrupted(ServerWorld w, BlockPos c) {
        for (int i = 0; i < 30; i++) {
            BlockPos p = c.add(w.random.nextInt(25) - 12, w.random.nextInt(13) - 6, w.random.nextInt(25) - 12);
            if (w.getBlockState(p).isOf(DecayBlocks.CORRUPTED_VOID) && w.getBlockState(p.up()).isAir() && w.getBlockState(p.up(2)).isAir())
                return p;
        }
        return null;
    }
}
