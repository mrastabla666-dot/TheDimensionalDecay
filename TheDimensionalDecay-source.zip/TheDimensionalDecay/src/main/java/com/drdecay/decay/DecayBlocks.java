package com.drdecay.decay;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;

import static com.drdecay.decay.DimensionalDecay.id;

public class DecayBlocks {
    public static final Block CORRUPTED_VOID = reg("corrupted_void", new CorruptedVoidBlock(
            AbstractBlock.Settings.create().mapColor(MapColor.PURPLE).strength(4f, 6f).requiresTool()
                    .luminance(s -> 3).sounds(BlockSoundGroup.SCULK)), true);

    public static final Block NULL_FLUID = reg("null_fluid", new NullFluidBlock(
            AbstractBlock.Settings.create().mapColor(MapColor.BLACK).strength(100f).noCollision().replaceable()
                    .dropsNothing().nonOpaque().luminance(s -> 7).pistonBehavior(PistonBehavior.DESTROY)
                    .allowsSpawning((s, w, p, t) -> false).suffocates((s, w, p) -> false).blockVision((s, w, p) -> false)), false);

    public static final Block ANCHOR_OF_LIGHT = reg("anchor_of_light", new AnchorOfLightBlock(
            AbstractBlock.Settings.create().mapColor(MapColor.WHITE).strength(5f, 1200f).requiresTool()
                    .luminance(s -> 15).sounds(BlockSoundGroup.GLASS)), true);

    public static final Block RIFT_CORE = reg("rift_core", new RiftCoreBlock(
            AbstractBlock.Settings.create().mapColor(MapColor.RED).strength(-1f, 3600000f).dropsNothing()
                    .luminance(s -> 10)), false);

    public static final Block SEALED_CORE = reg("sealed_core", new Block(
            AbstractBlock.Settings.create().mapColor(MapColor.CYAN).strength(-1f, 3600000f).dropsNothing()
                    .luminance(s -> 15)), true);

    private static Block reg(String name, Block block, boolean item) {
        Registry.register(Registries.BLOCK, id(name), block);
        if (item) Registry.register(Registries.ITEM, id(name), new BlockItem(block, new Item.Settings()));
        return block;
    }

    public static void init() {}
}
