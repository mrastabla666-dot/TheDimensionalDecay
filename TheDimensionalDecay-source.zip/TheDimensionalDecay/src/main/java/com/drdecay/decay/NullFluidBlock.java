package com.drdecay.decay;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/** Simplified "fluid": a block that spreads into adjacent water/lava, dissolves items and breaks redstone. */
public class NullFluidBlock extends Block {
    public NullFluidBlock(Settings settings) { super(settings); }

    @Override
    protected boolean isSideInvisible(BlockState state, BlockState adjacent, Direction direction) {
        return adjacent.isOf(this);
    }

    @Override
    protected void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity) {
        if (world.isClient) return;
        if (entity instanceof ItemEntity) {
            entity.discard();
        } else if (entity instanceof LivingEntity le && !DecayUtil.wearsFullNullArmor(le)) {
            if (world.getTime() % 10 == 0) le.damage(world.getDamageSources().magic(), 1.0f);
            le.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 2));
        }
    }

    @Override
    protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState old, boolean notify) {
        DecayUtil.breakRedstone(world, pos);
        if (!world.isClient) world.scheduleBlockTick(pos, this, 2);
    }

    @Override
    protected void neighborUpdate(BlockState state, World world, BlockPos pos, Block source, BlockPos sourcePos, boolean notify) {
        DecayUtil.breakRedstone(world, pos);
        if (!world.isClient && !world.getBlockTickScheduler().isQueued(pos, this)) world.scheduleBlockTick(pos, this, 2);
    }

    @Override
    protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        DecayUtil.convertLiquids(world, pos);
    }
}
