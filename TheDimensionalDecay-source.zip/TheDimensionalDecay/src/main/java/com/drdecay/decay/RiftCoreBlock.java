package com.drdecay.decay;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class RiftCoreBlock extends Block {
    public RiftCoreBlock(Settings settings) { super(settings); }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (world.isClient) return ActionResult.SUCCESS;
        if (!DecayUtil.wearsFullNullArmor(player)) {
            player.sendMessage(Text.literal("The rift rejects you. Wear a full set of Null-Armor to seal it."), true);
            return ActionResult.FAIL;
        }
        ServerWorld sw = (ServerWorld) world;
        DecayState st = DecayState.get(sw);
        st.sealed = true;
        st.markDirty();
        world.setBlockState(pos, DecayBlocks.SEALED_CORE.getDefaultState());
        for (int x = -24; x <= 24; x++) for (int y = -24; y <= 24; y++) for (int z = -24; z <= 24; z++) {
            BlockPos p = pos.add(x, y, z);
            BlockState s = world.getBlockState(p);
            if (s.isOf(DecayBlocks.CORRUPTED_VOID)) world.setBlockState(p, Blocks.DEEPSLATE.getDefaultState());
            else if (s.isOf(DecayBlocks.NULL_FLUID)) world.setBlockState(p, Blocks.AIR.getDefaultState());
        }
        world.playSound(null, pos, SoundEvents.BLOCK_END_PORTAL_SPAWN, SoundCategory.BLOCKS, 2f, 0.6f);
        sw.getServer().getPlayerManager().broadcast(
                Text.literal(player.getName().getString() + " sealed the Void Rift. The Decay has ended."), false);
        return ActionResult.SUCCESS;
    }
}
