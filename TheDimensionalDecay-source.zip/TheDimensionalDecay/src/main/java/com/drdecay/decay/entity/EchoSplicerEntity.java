package com.drdecay.decay.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayDeque;

/** Replays the nearest player's movement with a 2 second (40 tick) delay and hurts on contact. */
public class EchoSplicerEntity extends HostileEntity {
    private static final int DELAY = 40;
    private final ArrayDeque<Vec3d> history = new ArrayDeque<>();
    private int hitCooldown;

    public EchoSplicerEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        setNoGravity(true);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 20)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40);
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient) return;
        PlayerEntity p = getWorld().getClosestPlayer(this, 40);
        if (p == null || p.isSpectator() || p.isCreative()) { history.clear(); return; }

        history.addLast(p.getPos());
        if (history.size() > DELAY) {
            Vec3d v = history.pollFirst();
            refreshPositionAndAngles(v.x, v.y, v.z, p.getYaw(), 0);
            setVelocity(Vec3d.ZERO);
        }
        if (hitCooldown > 0) hitCooldown--;
        if (history.size() >= DELAY && hitCooldown == 0 && distanceTo(p) < 1.2f) {
            p.damage(getDamageSources().mobAttack(this), 4.0f);
            hitCooldown = 20;
        }
    }
}
