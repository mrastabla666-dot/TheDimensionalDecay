package com.drdecay.decay;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class GravityFractureEffect extends StatusEffect {
    public GravityFractureEffect() { super(StatusEffectCategory.HARMFUL, 0x3B0A5A); }

    @Override
    public boolean canApplyUpdateEffect(int duration, int amplifier) { return duration % 20 == 0; }

    @Override
    public boolean applyUpdateEffect(LivingEntity entity, int amplifier) {
        World w = entity.getWorld();
        if (w.isClient || DecayUtil.wearsFullNullArmor(entity)) return true;
        BlockPos o = entity.getBlockPos();
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (int dx = -8; dx <= 8; dx++) for (int dz = -8; dz <= 8; dz++) for (int dy = -8; dy <= -1; dy++) {
            BlockPos p = o.add(dx, dy, dz);
            if (w.getBlockState(p).isAir() && w.getBlockState(p.down()).isAir() && w.getBlockState(p.down(2)).isAir()) {
                double d = p.getSquaredDistance(o);
                if (d > 2 && d < bd) { bd = d; best = p; }
            }
        }
        Vec3d target = best != null ? Vec3d.ofBottomCenter(best) : entity.getPos().add(0, -6, 0);
        Vec3d dir = target.subtract(entity.getPos()).normalize().multiply(0.55);
        entity.addVelocity(dir.x, Math.min(dir.y, 0) - 0.1, dir.z);
        entity.velocityModified = true;
        return true;
    }
}
