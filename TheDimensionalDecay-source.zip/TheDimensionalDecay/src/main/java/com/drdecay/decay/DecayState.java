package com.drdecay.decay;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.PersistentState;

import java.util.HashSet;
import java.util.Set;

/** World-wide persistent data: rift position, sealed flag and Anchor positions. */
public class DecayState extends PersistentState {
    public boolean sealed, riftSet, riftPlaced;
    public int riftX, riftZ;
    public final Set<Long> anchors = new HashSet<>();

    public static final PersistentState.Type<DecayState> TYPE =
            new PersistentState.Type<>(DecayState::new, DecayState::fromNbt, null);

    public static DecayState get(ServerWorld world) {
        return world.getServer().getOverworld().getPersistentStateManager().getOrCreate(TYPE, "dimensional_decay");
    }

    public static DecayState fromNbt(NbtCompound n, RegistryWrapper.WrapperLookup lookup) {
        DecayState s = new DecayState();
        s.sealed = n.getBoolean("sealed");
        s.riftSet = n.getBoolean("riftSet");
        s.riftPlaced = n.getBoolean("riftPlaced");
        s.riftX = n.getInt("riftX");
        s.riftZ = n.getInt("riftZ");
        for (long l : n.getLongArray("anchors")) s.anchors.add(l);
        return s;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound n, RegistryWrapper.WrapperLookup lookup) {
        n.putBoolean("sealed", sealed);
        n.putBoolean("riftSet", riftSet);
        n.putBoolean("riftPlaced", riftPlaced);
        n.putInt("riftX", riftX);
        n.putInt("riftZ", riftZ);
        n.putLongArray("anchors", anchors.stream().mapToLong(Long::longValue).toArray());
        return n;
    }

    public void addAnchor(BlockPos p) { if (anchors.add(p.asLong())) markDirty(); }
    public void removeAnchor(BlockPos p) { if (anchors.remove(p.asLong())) markDirty(); }
}
