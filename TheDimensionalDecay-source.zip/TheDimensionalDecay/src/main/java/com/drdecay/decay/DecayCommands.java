package com.drdecay.decay;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;

public class DecayCommands {
    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, env) ->
                dispatcher.register(CommandManager.literal("decay")
                        .then(CommandManager.literal("rift").executes(ctx -> {
                            DecayState st = DecayState.get(ctx.getSource().getWorld());
                            ctx.getSource().sendFeedback(() -> Text.literal(
                                    "The Void Rift pulses near X " + st.riftX + ", Z " + st.riftZ + " (bottom of the world)."
                                            + (st.sealed ? " It is sealed." : "")), false);
                            return 1;
                        }))
                        .then(CommandManager.literal("status").executes(ctx -> {
                            DecayState st = DecayState.get(ctx.getSource().getWorld());
                            ctx.getSource().sendFeedback(() -> Text.literal(
                                    "Decay: " + (st.sealed ? "SEALED" : "ACTIVE") + " | Anchors of Light: " + st.anchors.size()), false);
                            return 1;
                        }))));
    }
}
