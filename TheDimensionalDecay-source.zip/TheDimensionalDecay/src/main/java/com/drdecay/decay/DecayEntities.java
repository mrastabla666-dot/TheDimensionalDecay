package com.drdecay.decay;

import com.drdecay.decay.entity.BedrockCrawlerEntity;
import com.drdecay.decay.entity.EchoSplicerEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

import static com.drdecay.decay.DimensionalDecay.id;

public class DecayEntities {
    public static final EntityType<BedrockCrawlerEntity> BEDROCK_CRAWLER = Registry.register(Registries.ENTITY_TYPE, id("bedrock_crawler"),
            EntityType.Builder.<BedrockCrawlerEntity>create(BedrockCrawlerEntity::new, SpawnGroup.MONSTER)
                    .dimensions(1.4f, 0.9f).maxTrackingRange(8).build("bedrock_crawler"));

    public static final EntityType<EchoSplicerEntity> ECHO_SPLICER = Registry.register(Registries.ENTITY_TYPE, id("echo_splicer"),
            EntityType.Builder.<EchoSplicerEntity>create(EchoSplicerEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 1.8f).maxTrackingRange(10).build("echo_splicer"));

    public static void init() {
        FabricDefaultAttributeRegistry.register(BEDROCK_CRAWLER, BedrockCrawlerEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(ECHO_SPLICER, EchoSplicerEntity.createAttributes());
    }
}
