package com.drdecay.decay;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

public class CorruptedVoidBlock extends Block {
    public CorruptedVoidBlock(Settings settings) { super(settings); }

    @Override
    public boolean hasRandomTicks(BlockState state) { return true; }

    @Override
    public void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        if (world.getRegistryKey() != World.OVERWORLD) return;
        if (DecayState.get(world).sealed || DecayUtil.isProtected(world, pos)) return;
        long t = world.getTimeOfDay() % 24000L;
        boolean night = t >= 13000L && t < 23000L;
        if (night && random.nextInt(3) == 0) {
            BlockPos n = pos.offset(Direction.random(random));
            if (DecayUtil.corruptible(world.getBlockState(n)) && !DecayUtil.isProtected(world, n)) {
                world.setBlockState(n, getDefaultState());
            }
        }
    }

    @Override
    protected void neighborUpdate(BlockState state, World world, BlockPos pos, Block source, BlockPos sourcePos, boolean notify) {
        schedule(world, pos);
    }

    @Override
    protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState old, boolean notify) {
        schedule(world, pos);
    }

    private void schedule(World world, BlockPos pos) {
        if (!world.isClient && !world.getBlockTickScheduler().isQueued(pos, this)) world.scheduleBlockTick(pos, this, 2);
    }

    @Override
    protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        DecayUtil.convertLiquids(world, pos);
    }
}
