package com.drdecay.decay;

import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;

public class DimensionalDecay implements ModInitializer {
    public static final String MOD_ID = "dimensional_decay";
    public static Identifier id(String path) { return Identifier.of(MOD_ID, path); }

    @Override
    public void onInitialize() {
        DecayBlocks.init();
        DecayEffects.init();
        DecayEntities.init();
        DecayItems.init();
        DecayTicker.init();
        DecayCommands.init();
    }
}
