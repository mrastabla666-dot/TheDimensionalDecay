package com.drdecay.decay;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.block.Blocks;

public class AnchorOfLightBlock extends Block {
    public AnchorOfLightBlock(Settings settings) { super(settings); }

    @Override
    protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState old, boolean notify) {
        if (world instanceof ServerWorld sw && world.getRegistryKey() == World.OVERWORLD) DecayState.get(sw).addAnchor(pos);
    }

    @Override
    protected void onStateReplaced(BlockState state, World world, BlockPos pos, BlockState newState, boolean moved) {
        if (!state.isOf(newState.getBlock()) && world instanceof ServerWorld sw) DecayState.get(sw).removeAnchor(pos);
        super.onStateReplaced(state, world, pos, newState, moved);
    }

    @Override
    public boolean hasRandomTicks(BlockState state) { return true; }

    /** The Anchor slowly purifies corruption inside its zone. */
    @Override
    public void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        for (int i = 0; i < 24; i++) {
            BlockPos p = pos.add(random.nextInt(33) - 16, random.nextInt(33) - 16, random.nextInt(33) - 16);
            BlockState s = world.getBlockState(p);
            if (s.isOf(DecayBlocks.CORRUPTED_VOID)) {
                world.setBlockState(p, p.getY() < 0 ? Blocks.DEEPSLATE.getDefaultState() : Blocks.STONE.getDefaultState());
            } else if (s.isOf(DecayBlocks.NULL_FLUID)) {
                world.setBlockState(p, Blocks.AIR.getDefaultState());
            }
        }
    }
}
