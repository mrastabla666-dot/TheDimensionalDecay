package com.drdecay.decay.entity;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Fast, near-blind spider that clings to ceilings and chews through obsidian. */
public class BedrockCrawlerEntity extends SpiderEntity {
    public BedrockCrawlerEntity(EntityType<? extends SpiderEntity> type, World world) { super(type, world); }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return SpiderEntity.createSpiderAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 30)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.42)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 12)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 5);
    }

    @Override
    public void tick() {
        super.tick();
        World w = getWorld();
        if (w.isClient) return;

        LivingEntity tg = getTarget();
        // "Blind": sneaking players are invisible to it beyond 3 blocks.
        if (tg instanceof PlayerEntity pl && pl.isSneaking() && distanceTo(pl) > 3) { setTarget(null); tg = null; }

        // Ceiling walking
        BlockPos above = BlockPos.ofFloored(getX(), getBoundingBox().maxY + 0.05, getZ());
        boolean ceiling = !w.getBlockState(above).getCollisionShape(w, above).isEmpty();
        if (ceiling) {
            boolean drop = tg != null && Math.hypot(tg.getX() - getX(), tg.getZ() - getZ()) < 1.5;
            setNoGravity(!drop);
            if (!drop) {
                Vec3d v = Vec3d.ZERO;
                if (tg != null) v = new Vec3d(tg.getX() - getX(), 0, tg.getZ() - getZ()).normalize().multiply(0.2);
                setVelocity(v);
            }
        } else {
            setNoGravity(false);
        }

        // Break player-placed obsidian
        if (tg != null && age % 10 == 0) {
            outer:
            for (Direction d : Direction.values()) {
                for (int k = 0; k < 2; k++) {
                    BlockPos p = getBlockPos().offset(d);
                    if (k == 1) { if (d.getAxis().isVertical()) continue; p = p.up(); }
                    BlockState s = w.getBlockState(p);
                    if (s.isOf(Blocks.OBSIDIAN) || s.isOf(Blocks.CRYING_OBSIDIAN)) { w.breakBlock(p, true, this); break outer; }
                }
            }
        }
    }
}
