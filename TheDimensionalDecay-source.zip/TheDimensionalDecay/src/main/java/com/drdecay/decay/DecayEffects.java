package com.drdecay.decay;

import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;

import static com.drdecay.decay.DimensionalDecay.id;

public class DecayEffects {
    public static final RegistryEntry<StatusEffect> GRAVITY_FRACTURE =
            Registry.registerReference(Registries.STATUS_EFFECT, id("gravity_fracture"), new GravityFractureEffect());

    public static void init() {}
}
