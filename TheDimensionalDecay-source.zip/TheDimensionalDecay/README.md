# The Dimensional Decay  (Fabric 1.21.1) — by Dr.Decay

## Build the jar
**Option A – locally:** install JDK 21 + Gradle 8.10+, then in this folder:
```
gradle build          # or: gradle wrapper && ./gradlew build
```
Jar appears in `build/libs/the-dimensional-decay-1.0.0.jar` (not the `-sources` one).
**Option B – no install:** push this folder to a GitHub repo; Actions builds it; download from the run's *Artifacts*.

Requires: Minecraft 1.21.1, Fabric Loader 0.16+, Fabric API 0.105.0+1.21.1, Java 21.

## Gameplay
- Bedrock/Deepslate at y=-64 and upward (higher as the world ages) dissolve into Corrupted Void Blocks. At night they spread.
- Standing on them: Gravity Fracture. Near them: no natural regen. Water/lava touching them become Null Fluid.
- Crafting: Void Shards (drop from Corrupted Void, needs iron pickaxe+) -> Null-Armor.
  Anchor of Light = End Rods, Nether Stars, Beacon, Crying Obsidian, Obsidian (radius 32 safe zone, slowly cures corruption).
- `/decay rift` shows the Rift's coordinates. Dig to the bottom, wear all 4 Null-Armor pieces, right-click the Rift Core to seal the Decay forever.
- `/decay status`
